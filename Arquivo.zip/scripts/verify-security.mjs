import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
import { getFirestore, collection, getDocs } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAqd5ypUjcPWOlzzXCanmrFIVg6B5_4TW0",
  authDomain: "ana-lima-psi-app.firebaseapp.com",
  projectId: "ana-lima-psi-app",
  storageBucket: "ana-lima-psi-app.firebasestorage.app",
  messagingSenderId: "648642882842",
  appId: "1:648642882842:web:b7b7680e3fbca1b52050a3"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

async function runAuditTests() {
  console.log('--- INICIANDO TESTES DE SEGURANÇA E ACESSO ---\n');

  // Teste 1: Tentativa de login com usuário inexistente
  console.log('[TESTE 1] Tentando login com e-mail não cadastrado (teste_seguranca@naoexiste.com)...');
  try {
    await signInWithEmailAndPassword(auth, 'teste_seguranca@naoexiste.com', 'SenhaFalsa123456!');
    console.error('FALHA: Login ou criação indevida ocorreu!');
  } catch (err) {
    console.log(`SUCESSO: Bloqueado como esperado pelo Firebase Auth.`);
    console.log(`         Código do Erro: ${err.code}`);
  }

  // Teste 2: Tentativa de leitura desautenticada em /public_intakes
  console.log('\n[TESTE 2] Tentando ler /public_intakes sem autenticação da Ana...');
  try {
    const snap = await getDocs(collection(db, 'public_intakes'));
    console.error('FALHA: Leitura desautenticada permitida!');
  } catch (err) {
    console.log(`SUCESSO: Acesso negado com sucesso pelas regras do Firestore.`);
    console.log(`         Código do Erro: ${err.code}`);
  }

  // Teste 3: Tentativa de leitura desautenticada em /users/psHLxoIeGfRNqQSwTbPUVxFCU8H2/patients
  console.log('\n[TESTE 3] Tentando ler subcoleção clínica da Ana (/users/psHLxoIeGfRNqQSwTbPUVxFCU8H2/patients)...');
  try {
    const snap = await getDocs(collection(db, 'users', 'psHLxoIeGfRNqQSwTbPUVxFCU8H2', 'patients'));
    console.error('FALHA: Leitura desautenticada permitida na subcoleção da Ana!');
  } catch (err) {
    console.log(`SUCESSO: Acesso negado com sucesso pelas regras do Firestore.`);
    console.log(`         Código do Erro: ${err.code}`);
  }

  // Teste 4: Tentativa de leitura desautenticada em /patients raiz
  console.log('\n[TESTE 4] Tentando ler /patients raiz sem ser a Ana...');
  try {
    const snap = await getDocs(collection(db, 'patients'));
    console.error('FALHA: Leitura desautenticada permitida na raiz!');
  } catch (err) {
    console.log(`SUCESSO: Acesso negado com sucesso pelas regras do Firestore.`);
    console.log(`         Código do Erro: ${err.code}`);
  }

  console.log('\n--- TODOS OS TESTES CONCLUÍDOS COM SUCESSO ---');
  process.exit(0);
}

runAuditTests().catch(err => {
  console.error('Erro inesperado na execução do script de teste:', err);
  process.exit(1);
});
