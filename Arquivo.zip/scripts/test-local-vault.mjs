// Teste automatizado do cofre criptográfico local (AES-256-GCM)
import { webcrypto } from 'node:crypto';

// Polyfill para Node.js
if (!globalThis.crypto) {
  globalThis.crypto = webcrypto;
}

// Mock sessionStorage e localStorage
const memorySessionStore = new Map();
const memoryLocalStore = new Map();

globalThis.sessionStorage = {
  getItem: (k) => memorySessionStore.get(k) || null,
  setItem: (k, v) => memorySessionStore.set(k, v),
  removeItem: (k) => memorySessionStore.delete(k)
};

globalThis.localStorage = {
  getItem: (k) => memoryLocalStore.get(k) || null,
  setItem: (k, v) => memoryLocalStore.set(k, v),
  removeItem: (k) => memoryLocalStore.delete(k)
};

// Importa funções do cofre
const { vaultSetItem, vaultGetItem, clearSessionVaultKey } = await import('../src/services/localVaultCrypto.ts');

async function runTest() {
  console.log('--- Testando Cofre Local Transparente (AES-256-GCM) ---');
  
  const testKey = 'ana_lima_records_v1';
  const plainText = JSON.stringify([
    { id: 'rec-test-1', patientName: 'Paciente Sigiloso Teste', evolution: 'Evolução confidencial clínica' }
  ]);

  // 1. Grava no cofre
  await vaultSetItem(testKey, plainText);

  // 2. Inspeciona o que foi salvo no localStorage em repouso
  const rawOnDisk = globalThis.localStorage.getItem(testKey);
  console.log('Valor bruto persistido no disco (localStorage):');
  console.log(rawOnDisk);

  const parsed = JSON.parse(rawOnDisk);
  if (!parsed._vault || !parsed.iv || !parsed.data) {
    throw new Error('FALHA: Os dados não foram gravados no container criptográfico _vault!');
  }
  if (rawOnDisk.includes('Paciente Sigiloso') || rawOnDisk.includes('Evolução confidencial')) {
    throw new Error('FALHA CRÍTICA: Texto puro vazou no disco!');
  }
  console.log('✅ Verificação 1: Texto puro NÃO está exposto em repouso no disco.');

  // 3. Decifra através do cofre
  const recovered = await vaultGetItem(testKey);
  if (recovered !== plainText) {
    throw new Error('FALHA: Texto recuperado difere do original!');
  }
  console.log('✅ Verificação 2: Decifração fiel com 100% de integridade.');

  // 4. Teste de migração retrocompatível (dados legados em texto puro)
  const legacyKey = 'ana_lima_patients_v1';
  const legacyPlain = JSON.stringify([{ id: 'pat-legado', name: 'Paciente Legado' }]);
  globalThis.localStorage.setItem(legacyKey, legacyPlain);

  const legacyRead = await vaultGetItem(legacyKey);
  if (legacyRead !== legacyPlain) {
    throw new Error('FALHA: Retrocompatibilidade com dados legados falhou!');
  }
  console.log('✅ Verificação 3: Retrocompatibilidade com dados legados funcionando.');

  // 5. Teste de expurgo ao deslogar
  clearSessionVaultKey();
  console.log('✅ Verificação 4: Chave de cofre removida com sucesso no encerramento da sessão.');

  console.log('🎉 TODOS OS TESTES DO COFRE LOCAL PASSARAM COM SUCESSO!');
}

runTest().catch((err) => {
  console.error('❌ Erro no teste do cofre:', err);
  process.exit(1);
});
