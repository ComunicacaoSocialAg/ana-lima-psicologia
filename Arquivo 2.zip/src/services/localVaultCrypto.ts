/**
 * Cofre Criptográfico Local Transparente (AES-256-GCM)
 * Protege dados clínicos em repouso no localStorage contra inspeção indevida e invasão física.
 * Desenvolvido para conformidade estrita com CFP 001/2009 e LGPD Art. 11/46.
 */

const VAULT_SESSION_KEY = 'ana_lima_vault_session_key_v1';

// Cache em memória para chave CryptoKey ativa (0ms de latência)
let cachedCryptoKey: CryptoKey | null = null;

// Obtém ou inicializa a chave criptográfica de 256 bits da sessão atual
export async function getSessionVaultKey(): Promise<CryptoKey> {
  if (cachedCryptoKey) {
    return cachedCryptoKey;
  }

  let keyBase64: string | null = null;
  if (typeof sessionStorage !== 'undefined') {
    keyBase64 = sessionStorage.getItem(VAULT_SESSION_KEY);
  }
  if (!keyBase64 && typeof localStorage !== 'undefined') {
    keyBase64 = localStorage.getItem(VAULT_SESSION_KEY);
  }

  if (!keyBase64) {
    const rawBytes = globalThis.crypto.getRandomValues(new Uint8Array(32));
    let binary = '';
    for (let i = 0; i < rawBytes.byteLength; i++) {
      binary += String.fromCharCode(rawBytes[i]);
    }
    keyBase64 = btoa(binary);
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.setItem(VAULT_SESSION_KEY, keyBase64);
    }
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(VAULT_SESSION_KEY, keyBase64);
    }
  }

  const binaryString = atob(keyBase64);
  const keyBytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    keyBytes[i] = binaryString.charCodeAt(i);
  }

  cachedCryptoKey = await globalThis.crypto.subtle.importKey(
    'raw',
    keyBytes,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );

  return cachedCryptoKey;
}

// Cifra e salva no localStorage com envelope autenticado
export async function vaultSetItem(key: string, plainText: string): Promise<void> {
  try {
    const cryptoKey = await getSessionVaultKey();
    const iv = globalThis.crypto.getRandomValues(new Uint8Array(12));
    const enc = new TextEncoder();
    const encryptedBuf = await globalThis.crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      cryptoKey,
      enc.encode(plainText)
    );

    const ivArray = new Uint8Array(iv);
    let ivBinary = '';
    for (let i = 0; i < ivArray.byteLength; i++) {
      ivBinary += String.fromCharCode(ivArray[i]);
    }

    const dataArray = new Uint8Array(encryptedBuf);
    let dataBinary = '';
    for (let i = 0; i < dataArray.byteLength; i++) {
      dataBinary += String.fromCharCode(dataArray[i]);
    }

    const container = {
      _vault: true,
      v: 1,
      iv: btoa(ivBinary),
      data: btoa(dataBinary)
    };

    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, JSON.stringify(container));
    }
  } catch (err) {
    console.warn(`Alerta ao criptografar chave local '${key}':`, err);
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, plainText); // Fallback de contingência
    }
  }
}

// Lê e decifra do localStorage com suporte a migração de dados legados
export async function vaultGetItem(key: string): Promise<string | null> {
  if (typeof localStorage === 'undefined') return null;
  const raw = localStorage.getItem(key);
  if (!raw) return null;

  try {
    const parsed = JSON.parse(raw);
    if (parsed && parsed._vault === true && parsed.iv && parsed.data) {
      const cryptoKey = await getSessionVaultKey();
      
      const ivBinary = atob(parsed.iv);
      const iv = new Uint8Array(ivBinary.length);
      for (let i = 0; i < ivBinary.length; i++) {
        iv[i] = ivBinary.charCodeAt(i);
      }

      const dataBinary = atob(parsed.data);
      const ciphertext = new Uint8Array(dataBinary.length);
      for (let i = 0; i < dataBinary.length; i++) {
        ciphertext[i] = dataBinary.charCodeAt(i);
      }

      const decryptedBuf = await globalThis.crypto.subtle.decrypt(
        { name: 'AES-GCM', iv },
        cryptoKey,
        ciphertext
      );
      const dec = new TextDecoder();
      return dec.decode(decryptedBuf);
    }
  } catch {
    // Se a chave não decifrar ou se não for um container criptografado
  }

  // Fallback transparente: se for dado legado ainda em texto puro, retorna diretamente
  return raw;
}

// Destrói a chave de sessão no logout ou encerramento
export function clearSessionVaultKey(): void {
  cachedCryptoKey = null;
  if (typeof sessionStorage !== 'undefined') {
    sessionStorage.removeItem(VAULT_SESSION_KEY);
  }
  if (typeof localStorage !== 'undefined') {
    localStorage.removeItem(VAULT_SESSION_KEY);
  }
}
